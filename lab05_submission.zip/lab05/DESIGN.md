# Campus Workshop Board - Design notes
Name: ____________________  
Student ID: ____________________

## Diagram files
| View | Editable source (and page if needed) | Export |
|---|---|---|
| 01-context | `diagrams/source/01-context.mmd` | `diagrams/exports/01-context.svg` |
| 02-containers | `diagrams/source/02-containers.mmd` | `diagrams/exports/02-containers.svg` |
| 03-components | `diagrams/source/03-components.mmd` | `diagrams/exports/03-components.svg` |
| 04-code | `diagrams/source/04-code.mmd` | `diagrams/exports/04-code.svg` |
| 05-dynamic | `diagrams/source/05-dynamic.mmd` | `diagrams/exports/05-dynamic.svg` |

## One structural choice (Exercise 2)
The pilot uses one modular Board API application with separate relational persistence because this keeps deployment and operations simple for one small team while clear interfaces preserve room to split components later.

## Your components (Exercise 3)
| Name | Job | Customer rule(s) served |
|---|---|---|
| Identity Gateway | Verifies a university credential through Campus Identity and maps it to a signed-in student identity. | R1, R4 |
| Workshop Catalogue | Creates, validates, publishes and reads workshop summaries; enforces owner-only publishing. | R2, R3 |
| Reservation Rules | Performs idempotent, capacity-safe reservation decisions and coordinates confirmation mail. | R3, R4, R6 |
| Reservation Repository | Reads and atomically writes workshops, ownership and reservations in the database. | R4, R5 |
| Mail Notifier | Requests reservation confirmation from University Mail and reports availability. | R6 |

## Reservation operation (Exercise 4)
`reserve(student: StudentId, workshop: WorkshopId) -> ExistingReservation | ReservationCreated(reservationId, remainingSeats) | WorkshopFull | UnverifiedStudent | WorkshopNotPublished | WorkshopNotFound`.

The invariant is `0 <= reservationCount(workshop) <= capacity` and at most one reservation exists for each `(studentId, workshopId)`. The repository performs a transaction that locks the workshop row, checks for an existing reservation before capacity, and inserts at most one unique `(studentId, workshopId)` row before updating the count. Therefore overlapping calls serialize at the decision point: a repeat returns the same reservation unchanged, while new calls cannot oversubscribe the capacity.

## Ari's incident (Exercise 5)
| Observation | Result |
|---|---|
| Stored state before | W17 is published, owner S10, capacity 3; reservations are S21 and S22; Ari S23 has none. |
| Stored state after | W17 still has reservations S21 and S22; Ari S23 is added as the third reservation. Mail delivery is not stored as a condition for success. |
| Message Ari sees | `Reservation succeeded for W17, but confirmation email is unavailable.` |

The dynamic trace in `05-dynamic.mmd` shows the storage commit before the failed mail request and the successful result returned to Ari.
