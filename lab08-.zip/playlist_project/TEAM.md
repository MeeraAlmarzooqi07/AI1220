# Team

Replace the placeholders below with the pair's real names and GitHub usernames before pushing.

| Name | GitHub username | Role |
| --- | --- | --- |
| Your name | your-github-username | backend |
| Partner's name | partner-github-username | frontend |
