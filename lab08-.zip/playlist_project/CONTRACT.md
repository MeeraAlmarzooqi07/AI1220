# Playlist API contract

Both clients and the server use this contract. The server runs on `http://127.0.0.1:8000`.

## 1. Get all songs

Method: `GET`

Path: `/songs`

Request body: none

Response status: `200`

Response body (the three starting songs):

```json
[
  {"id": 1, "title": "Blue Monday", "artist": "New Order", "votes": 3},
  {"id": 2, "title": "Clocks", "artist": "Coldplay", "votes": 1},
  {"id": 3, "title": "Dancing Queen", "artist": "ABBA", "votes": 0}
]
```

## 2. Add a song

Method: `POST`

Path: `/songs`

Request body:

```json
{"title": "Song title", "artist": "Artist name"}
```

Response status: `201`

Response body:

```json
{"id": 4, "title": "Song title", "artist": "Artist name", "votes": 0}
```

Error status (title or artist missing or empty): `400`

Error body:

```json
{"error": "Title and artist are required"}
```

## 3. Vote for a song

Method: `POST`

Path (write the song's id as `{id}`, for example `/songs/{id}/votes`): `/songs/{id}/votes`

Request body: none

Response status: `200`

Response body:

```json
{"id": 1, "title": "Blue Monday", "artist": "New Order", "votes": 4}
```

Error status (no song with that id): `404`

Error body:

```json
{"error": "There is no song with that id"}
```
