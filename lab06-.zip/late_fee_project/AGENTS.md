# Project rules

- `REQUIREMENTS.md` is the source of truth for the acceptance criteria for `late_fee`.
- Tests use Python's standard-library `unittest` framework.
- Tests live in `tests/` and import the function with `from fees import late_fee`.
- Run the tests from the `lab06` directory with:
  `python3 -m unittest discover -s tests`
- Use only the Python standard library.
- Keep `REQUIREMENTS.md` and `fees.py` unchanged for this lab.
